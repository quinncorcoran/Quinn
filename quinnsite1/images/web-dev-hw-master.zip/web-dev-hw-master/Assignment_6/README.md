Describe any forms you've come across while browsing the web. What purposes do the serve?
  The most common form I have come across is the log-in form where you have to enter in
  a username and a password. Another form that I see a lot are forms asking for
  comments. These forms allow the user to interact with the web page and enter into
  another area or allow other people to see what they want to share about a topic.

List examples of a text, selection, and button input, and where they might be used.
  The most obvious example of a text input is the log in screens that come up everyday.
  They exist in websites with e-mail, social media, schools, newspapers, and many others.
  I see selection inputs most commonly in online tests or places where you vote online.
  Button inputs exist everywhere, like the buttons that bring you to other areas of
  websites, or the buttons found at the bottom of web pages that usually link to related
  sites.

Free Response: Summarize your work cycle for this assignment.
  On this assignment I sat down and read through the website that was provided on
  Moodle. Then I read the assignment and completed it step by step. The website is
  by far the most helpful resource to complete the assignments.
