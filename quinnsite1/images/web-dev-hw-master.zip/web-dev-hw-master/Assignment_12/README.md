Who was your imaginary client? How did they describe their site needs?
  I imagined that I was building a site where I could connect all of my
  previous sites so that they were all in one place. Some requirements I had
  were to include past projects and to make it easy to navigate through.

What is the difference between display: block, display: inline, and display: inline-block?
  The difference is that display block you can use as a block element spacing wise,
  display inline allows the elements to be displayed next to eachother in a line,
  and block inline allows the blocks to be displayed in a line. I've most often had to
  use display block inline.

Free Response: Summarize your work cycle for this assignment.
  I missed the due date for this assignment because of thanksgiving break, but
  I finished it the way I have for most of these assignments. Sat down and read
  the material then went to work on the site. I had fun with this one.
