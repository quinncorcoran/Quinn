How many main document <head> and <body> elements can a page have? How are these elements different, or what role do they play?

  An html document can only have one body element and should only have one head element.
  The head element is a container for the descriptive properties of the document, like the metadata.
  The body element is where the meat of a document is and is the container for the actual material.

Describe the difference between structural and semantic markup.

  Structural markup includes important descriptive pieces of the document like paragraphs,
  lists, and headers. Semantic adds details such as italics, bold text, or emphasis.
  Structural puts together the document while semantic details it.

Free Response: Summarize your work cycle for this assignment.

  Typically I have saved these assignments for the end of the week. I enjoy sitting on my computer
  and figuring out what I can do in html and watching the videos, so saving the assignments until
  later in the week gives me more time to do that. Once I start working on the assignment it is tough
  to stop, so I usually dedicate time on Sunday or Monday for it when other classes are not as stressful.
