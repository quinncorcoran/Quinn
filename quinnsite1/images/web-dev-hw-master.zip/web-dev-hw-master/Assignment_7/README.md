Briefly describe the difference between divs, classes, ids, and spans.
  Divs are used to block elements together, Classes are used to classify and group
  elements, id's are used to give each element a unique identifier, and span elements
  are a way to div or style inside existing div blocks. Span and divs are similar,
  and ids and classes are similar. Although each are different and have their own
  jobs.

What is "alt text," and why do we use it?
  Alt text is the text that is displayed when the associated element cannot be
  loaded or isn't available. It is like having a back up plan.

Free Response: Summarize your work cycle for this assignment.
  I approached this assignment similarly to the previous assignments, but I am doing
  it early this week because I will be out of town for the weekend and next week.
  I read through the website then read through the assignment and completed it.
