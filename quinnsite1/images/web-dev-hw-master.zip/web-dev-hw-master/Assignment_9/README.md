Describe the difference between the universal, element, class, and id selector types. When might you choose one over the other to style content?

  The difference between universal, element, class, and ID selector types are that they
  apply to different levels. Universal applies to everything, element to just elements, class to more
  specific classes, and finally ids to individual items with that id. The difference is
  the scope that they cover.

Briefly discuss your color palette, including the 3 colors you chose. List their color names, rgb values, or hex codes

  I chose colors that I found in the pictures that I collected from staple 80's items.
  Three examples are #0112FE (the blue), #FE7701 (the light lime green), and finally
  #BB01FE (the purple). I feel like the represent the 80's items well, and I like
  how it looks.

Free Response: Summarize your work cycle for this assignment.

  I used the same work cycle I have been using. Putting a lot of time Sunday and Monday into it.
  I review the material such as the website and walkthrough on Sunday, then complete
  the assignment on Monday.
