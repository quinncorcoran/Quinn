A system font is supposed to be used on your computer and usually stored in the computers
files somewhere, while a web-font is a font designated and especially good for using on the
web with CSS. A web-free font is a font that can be found on the web that can usually be used
both ways, safely on the web and on the computer.

Fallback fonts are important because if a web-user cannot load the specific font you designated,
then it will use the given fallback font and avoid using a font that would otherwise not
look close to the previously failed font.

I used the same work cycle I have been using. Putting a lot of time Sunday and Monday into it.
I review the material such as the website and walkthrough on Sunday, then complete
the assignment on Monday.
