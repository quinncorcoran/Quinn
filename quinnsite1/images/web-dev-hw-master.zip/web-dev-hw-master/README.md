# Evan Wilken's web-dev-hw
Homework repository for Intro to Web Design.
My name is Evan Wilken and I am majoring in Economics and minoring in Computer Science. I'm from Fairbanks, Alaska and have really been enjoying fishing in the hot, sunny weather since I've been back in Missoula. I haven't learned much about web design and I'm excited to take this class!
