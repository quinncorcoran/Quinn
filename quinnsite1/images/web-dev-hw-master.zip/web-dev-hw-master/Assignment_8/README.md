Learning HTML was a lot of fun. I've worked with iframes before, but all the structural items were
cool and new for me. I enjoyed learning how to add more structure and a better framework
to my HTML sites.

Nothing really comes to mind that I'm excited about in CSS. I think it will be nice to add more
style to the web pages though.

For this assignment I worked over the weekend and on Monday to complete it. I got held up on
the formatting a few times so it took me a while to complete.
