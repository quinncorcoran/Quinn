Did you learn anything new about web development (ie using GitHub, version control, repositories)?
  I learned a lot and improved a ton with everything involving web development.
  I even used the method of hosting sites on github with another class, and
  taught other students how to do the same. It's really cool!

Did you learn anything new about web design (ie using media, color, fonts)?
  I learned everything about web design. I didn't know any CSS previously so
  learning everything this semester really improved my web design skills, or
  created them I guess.

Free Response: Summarize your work cycle for this assignment.
  I completed the final just like the previous assignments. I used a lot of the
  past weeks assignment elements to complete it, and did it over a couple of days.
  I enjoyed making this one.
